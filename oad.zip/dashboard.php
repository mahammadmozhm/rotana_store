<?php require 'inc.php'; require 'lib.php'; $me=require_login();
if(!can('orders')) redir('index.php');
$tabs=['overview'=>['نظرة عامة',1],'employees'=>['الموظفون',1],'orders'=>['الطلبات',0],'account'=>['حساب الأدمن',1],'settings'=>['إعدادات الموقع',1],'telegram'=>['بوت تلكرام',1]];
$tab=$_GET['tab']??(is_admin()?'overview':'orders');
if(!isset($tabs[$tab])||($tabs[$tab][1]&&!is_admin())) $tab='orders';
$staff=$pdo->query("SELECT id,full_name FROM users WHERE role='staff' AND active=1 ORDER BY full_name")->fetchAll();
ob_start(); include "tabs/$tab.php"; $body=ob_get_clean();
head('لوحة التحكم');
echo '<div class="tabs">';
foreach($tabs as $k=>[$n,$adm]){ if($adm&&!is_admin()) continue; echo '<a class="'.($k===$tab?'on':'').'" href="?tab='.$k.'">'.$n.'</a>'; }
echo '</div>'; show_flash(); echo $body; foot();
