<?php
require __DIR__.'/config.php';
header('Content-Type: text/html; charset=utf-8');
try{
  $pdo=new PDO("mysql:host=".DB_HOST.";charset=utf8mb4",DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  $pdo->exec("CREATE DATABASE IF NOT EXISTS `".DB_NAME."` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
  $pdo->exec("USE `".DB_NAME."`");
  $pdo->exec("CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,full_name VARCHAR(150) NOT NULL,username VARCHAR(60) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,phone VARCHAR(30) DEFAULT '',role ENUM('admin','staff') DEFAULT 'staff',perm_status TINYINT DEFAULT 1,perm_orders TINYINT DEFAULT 0,perm_reports TINYINT DEFAULT 0,active TINYINT DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $pdo->exec("CREATE TABLE IF NOT EXISTS orders(id INT AUTO_INCREMENT PRIMARY KEY,order_no VARCHAR(50) NOT NULL UNIQUE,full_name VARCHAR(150) DEFAULT '',phone VARCHAR(30) DEFAULT '',region VARCHAR(100) DEFAULT '',status ENUM('pending','delivered','rejected') DEFAULT 'pending',updated_by INT NULL,updated_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $pdo->exec("CREATE TABLE IF NOT EXISTS order_users(order_id INT NOT NULL,user_id INT NOT NULL,PRIMARY KEY(order_id,user_id),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $pdo->exec("CREATE TABLE IF NOT EXISTS status_log(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,user_id INT NULL,old_status VARCHAR(20),new_status VARCHAR(20),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $pdo->exec("CREATE TABLE IF NOT EXISTS settings(k VARCHAR(50) PRIMARY KEY,v TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  if(!$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn()){
    $pdo->prepare("INSERT INTO users(full_name,username,password,role,perm_status,perm_orders,perm_reports) VALUES('المدير','admin',?,'admin',1,1,1)")->execute([password_hash('admin123',PASSWORD_DEFAULT)]);
    $pdo->exec("INSERT IGNORE INTO settings(k,v) VALUES('site_name','نظام الطلبات'),('color_primary','#2563eb'),('color_secondary','#0f172a'),('footer_text','جميع الحقوق محفوظة')");
  }
  echo '<h2 style="font-family:Tahoma">✅ تم التثبيت</h2><p style="font-family:Tahoma">المستخدم: <b>admin</b> — كلمة المرور: <b>admin123</b> (غيّرها فورًا)<br><a href="login.php">اذهب لتسجيل الدخول</a><br><b>احذف ملف install.php بعد التثبيت.</b></p>';
}catch(Exception $e){ echo 'خطأ: '.htmlspecialchars($e->getMessage()); }
