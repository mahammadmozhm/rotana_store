(function(){
  const box=document.getElementById('q'); if(!box) return;
  const res=document.getElementById('results'), csrf=document.querySelector('meta[name=csrf]').content;
  const L={pending:'غير مصنف',delivered:'تم التوصيل',rejected:'تم رفض التوصيل'}; let t;
  const esc=s=>{const d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML;};
  async function search(){
    const q=box.value.trim(); if(!q){res.innerHTML='';return;}
    const j=await (await fetch('api.php?action=search&q='+encodeURIComponent(q))).json();
    if(!j.rows||!j.rows.length){res.innerHTML='<p class="empty">لا توجد نتائج</p>';return;}
    res.innerHTML=j.rows.map(o=>`<div class="card order"><div class="ono">#${esc(o.order_no)}</div><div class="nm">${esc(o.full_name)}</div><div class="meta"><span>📞 <a href="tel:${esc(o.phone)}">${esc(o.phone)}</a></span><span>📍 ${esc(o.region)}</span></div><div class="st st-${o.status}">${L[o.status]}</div>${j.can?`<div class="btns">${Object.keys(L).map(k=>`<button class="b-${k}${k===o.status?' on':''}" data-id="${o.id}" data-s="${k}">${L[k]}</button>`).join('')}</div>`:''}${o.by_name?`<small>آخر تعديل: ${esc(o.by_name)} — ${esc(o.updated_at||'')}</small>`:''}</div>`).join('');
  }
  box.addEventListener('input',()=>{clearTimeout(t);t=setTimeout(search,250);});
  res.addEventListener('click',async e=>{
    const b=e.target.closest('button[data-id]'); if(!b) return; b.disabled=true;
    const f=new FormData(); f.append('csrf',csrf); f.append('id',b.dataset.id); f.append('status',b.dataset.s);
    await fetch('api.php?action=status',{method:'POST',body:f}); search();
  });
})();
document.querySelectorAll('.assign').forEach(a=>{
  const sb=a.querySelector('.staffbox');
  a.querySelectorAll('input[name=vis]').forEach(r=>r.addEventListener('change',()=>{sb.hidden=a.querySelector('input[name=vis]:checked').value!=='specific';}));
});
document.querySelectorAll('[data-confirm]').forEach(f=>f.addEventListener('submit',e=>{if(!confirm(f.dataset.confirm))e.preventDefault();}));
