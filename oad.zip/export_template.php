<?php require 'inc.php'; require 'lib.php'; require_login(); if(!can('orders')) redir('index.php');
$tmp=tempnam(sys_get_temp_dir(),'tpl');
xlsx_write([['رقم الطلب','الاسم الثلاثي','رقم الهاتف','المنطقة'],['1001','أحمد علي حسين','07701234567','كربلاء - حي الحسين'],['1002','محمد كاظم جاسم','07801234567','كربلاء - المخيم'],['1003','زينب حسن علي','07501234567','الهندية']],$tmp);
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="orders_template.xlsx"'); header('Content-Length: '.filesize($tmp));
readfile($tmp); unlink($tmp);
