<?php require 'inc.php'; header('Content-Type: application/json; charset=utf-8');
$u=user(); if(!$u){ http_response_code(401); echo '{"error":"auth"}'; exit; }
$a=$_GET['action']??'';
if($a==='search'){
  $q=trim($_GET['q']??''); if($q===''){ echo '{"rows":[]}'; exit; }
  [$v,$p]=visible_sql('o');
  $s=$pdo->prepare("SELECT o.id,o.order_no,o.full_name,o.phone,o.region,o.status,o.updated_at,u.full_name AS by_name FROM orders o LEFT JOIN users u ON u.id=o.updated_by WHERE o.order_no LIKE ? AND $v ORDER BY o.order_no LIMIT 20");
  $s->execute(array_merge(['%'.addcslashes($q,'%_\\').'%'],$p));
  echo json_encode(['can'=>can('status'),'rows'=>$s->fetchAll()],JSON_UNESCAPED_UNICODE); exit; }
if($a==='status' && $_SERVER['REQUEST_METHOD']==='POST'){
  check_csrf(); if(!can('status')){ http_response_code(403); echo '{"error":"perm"}'; exit; }
  $id=(int)($_POST['id']??0); [$v,$p]=visible_sql('o');
  $s=$pdo->prepare("SELECT o.id FROM orders o WHERE o.id=? AND $v"); $s->execute(array_merge([$id],$p));
  if(!$s->fetch()){ http_response_code(403); echo '{"error":"hidden"}'; exit; }
  change_status($id,$_POST['status']??'',$u['id']); echo '{"ok":1}'; exit; }
http_response_code(400); echo '{}';
