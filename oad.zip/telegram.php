<?php require 'inc.php'; require 'lib.php';
$sec=setting('tg_secret'); if($sec===''||!hash_equals($sec,$_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']??'')){ http_response_code(403); exit; }
$up=json_decode(file_get_contents('php://input'),true); $m=$up['message']??null; if(!$m) exit;
$chat=$m['chat']['id']; $allowed=array_filter(explode(',',setting('tg_chat_ids')));
function say($c,$t){ tg('sendMessage',['chat_id'=>$c,'text'=>$t]); }
if(!in_array((string)$chat,$allowed,true)){ say($chat,"غير مصرح لك.\nمعرّف المحادثة: $chat\nأعطه للأدمن ليضيفه."); exit; }
if(!empty($m['document'])){ $d=$m['document']; $ext=strtolower(pathinfo($d['file_name']??'',PATHINFO_EXTENSION));
  if(!in_array($ext,['xlsx','csv'])){ say($chat,'أرسل ملف xlsx أو csv فقط.'); exit; }
  $f=tg('getFile',['file_id'=>$d['file_id']]); $path=$f['result']['file_path']??null;
  if(!$path){ say($chat,'تعذر تنزيل الملف.'); exit; }
  $data=@file_get_contents('https://api.telegram.org/file/bot'.setting('tg_token').'/'.$path);
  $tmp=tempnam(sys_get_temp_dir(),'tg'); file_put_contents($tmp,$data);
  [$a,$s]=import_rows(read_sheet($tmp,$ext)); unlink($tmp);
  say($chat,"✅ تم استيراد $a طلب\n⏭ تم تخطي $s (مكرر/غير صالح)"); exit; }
$t=trim($m['text']??'');
if(strpos($t,'|')!==false){ [$a,$s]=import_rows([array_map('trim',explode('|',$t))]); say($chat,$a?'✅ تمت إضافة الطلب':'⏭ الطلب مكرر أو غير صالح'); exit; }
say($chat,"أرسل ملف Excel (xlsx/csv) بالأعمدة:\nرقم الطلب | الاسم الثلاثي | رقم الهاتف | المنطقة\nأو طلباً واحداً نصياً بالشكل:\n1001 | أحمد علي حسين | 0770... | كربلاء");
