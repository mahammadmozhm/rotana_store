<?php
// ===== Excel (xlsx) بدون مكتبات خارجية + CSV =====
function xlsx_write($rows,$path){
  $z=new ZipArchive; $z->open($path,ZipArchive::CREATE|ZipArchive::OVERWRITE);
  $h='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  $z->addFromString('[Content_Types].xml',$h.'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
  $z->addFromString('_rels/.rels',$h.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
  $z->addFromString('xl/workbook.xml',$h.'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>');
  $z->addFromString('xl/_rels/workbook.xml.rels',$h.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
  $x=$h.'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews><sheetData>';
  foreach($rows as $i=>$r){ $x.='<row r="'.($i+1).'">';
    foreach(array_values($r) as $j=>$v){ $x.='<c r="'.chr(65+$j).($i+1).'" t="inlineStr"><is><t xml:space="preserve">'.htmlspecialchars((string)$v,ENT_XML1|ENT_QUOTES,'UTF-8').'</t></is></c>'; }
    $x.='</row>'; }
  $z->addFromString('xl/worksheets/sheet1.xml',$x.'</sheetData></worksheet>'); $z->close(); }

function xlsx_read($path){
  $z=new ZipArchive; if($z->open($path)!==true) return [];
  $ss=[]; if(($t=$z->getFromName('xl/sharedStrings.xml'))!==false){ $sx=simplexml_load_string($t);
    foreach($sx->si as $si){ if(isset($si->t)) $ss[]=(string)$si->t; else { $s=''; foreach($si->r as $r) $s.=(string)$r->t; $ss[]=$s; } } }
  $sheet=$z->getFromName('xl/worksheets/sheet1.xml'); if($sheet===false) return [];
  $sx=simplexml_load_string($sheet); $rows=[];
  foreach($sx->sheetData->row as $row){ $r=[];
    foreach($row->c as $c){ preg_match('/^([A-Z]+)/',(string)$c['r'],$m); $col=0; foreach(str_split($m[1]) as $ch) $col=$col*26+ord($ch)-64; $col--;
      $t=(string)$c['t']; if($t==='s') $v=$ss[(int)$c->v]??''; elseif($t==='inlineStr') $v=(string)$c->is->t; else $v=(string)$c->v;
      $r[$col]=$v; }
    if($r){ $max=max(array_keys($r)); $o=[]; for($i=0;$i<=$max;$i++) $o[]=$r[$i]??''; $rows[]=$o; } }
  return $rows; }

function read_sheet($path,$ext){
  if($ext==='xlsx') return xlsx_read($path);
  $rows=[]; if(($f=fopen($path,'r'))===false) return [];
  while(($r=fgetcsv($f))!==false){ if(isset($r[0])) $r[0]=preg_replace('/^\xEF\xBB\xBF/','',$r[0]); $rows[]=$r; } fclose($f); return $rows; }

function import_rows($rows,$ids=[]){ global $pdo; $add=0;$skip=0;
  $ins=$pdo->prepare("INSERT INTO orders(order_no,full_name,phone,region) VALUES(?,?,?,?)");
  foreach($rows as $i=>$r){ $r=array_pad(array_map('trim',$r),4,'');
    if($i===0 && preg_match('/\p{Arabic}|order/iu',$r[0])) continue;
    if($r[0]==='') continue;
    if(preg_match('/^7\d{9}$/',$r[2])) $r[2]='0'.$r[2];
    try{ $ins->execute([$r[0],$r[1],$r[2],$r[3]]); $oid=$pdo->lastInsertId();
      foreach($ids as $uid) $pdo->prepare("INSERT IGNORE INTO order_users(order_id,user_id) VALUES(?,?)")->execute([$oid,(int)$uid]);
      $add++; }catch(PDOException $e){ $skip++; } }
  return [$add,$skip]; }

function save_assign($oid,$ids){ global $pdo; $pdo->prepare("DELETE FROM order_users WHERE order_id=?")->execute([$oid]);
  foreach($ids as $uid) $pdo->prepare("INSERT IGNORE INTO order_users(order_id,user_id) VALUES(?,?)")->execute([$oid,(int)$uid]); }
function posted_assign(){ return (($_POST['vis']??'all')==='specific') ? array_map('intval',$_POST['users']??[]) : []; }
function assign_box($staff,$sel=[]){ $sp=count($sel)>0;
  $h='<div class="assign"><label><input type="radio" name="vis" value="all"'.($sp?'':' checked').'> تظهر للجميع</label> <label><input type="radio" name="vis" value="specific"'.($sp?' checked':'').'> موظفين محددين فقط</label><div class="staffbox"'.($sp?'':' hidden').'>';
  foreach($staff as $s) $h.='<label><input type="checkbox" name="users[]" value="'.$s['id'].'"'.(in_array($s['id'],$sel)?' checked':'').'> '.e($s['full_name']).'</label>';
  return $h.'</div></div>'; }

// ===== تلكرام =====
function tg($method,$data=[]){ $t=setting('tg_token'); if(!$t) return null;
  $ch=curl_init("https://api.telegram.org/bot$t/$method");
  curl_setopt_array($ch,[CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>$data,CURLOPT_RETURNTRANSFER=>1,CURLOPT_TIMEOUT=>30]);
  $r=curl_exec($ch); curl_close($ch); return json_decode((string)$r,true); }
