<?php
$c=$pdo->query("SELECT status,COUNT(*) FROM orders GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
$log=$pdo->query("SELECT l.*,o.order_no,u.full_name AS who FROM status_log l JOIN orders o ON o.id=l.order_id LEFT JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 50")->fetchAll();
?>
<div class="grid">
  <div class="card stat"><b><?= array_sum($c) ?></b>كل الطلبات</div>
  <?php foreach(STATUS as $k=>$n): ?><div class="card stat"><b><?= (int)($c[$k]??0) ?></b><?= $n ?></div><?php endforeach; ?>
</div>
<div class="card"><h3>آخر تغييرات حالة الطلبات</h3>
<div class="tw"><table><tr><th>الطلب</th><th>من</th><th>إلى</th><th>بواسطة</th><th>الوقت</th></tr>
<?php foreach($log as $l): ?><tr><td>#<?= e($l['order_no']) ?></td><td><?= e(STATUS[$l['old_status']]??'') ?></td><td><span class="st st-<?= e($l['new_status']) ?>"><?= e(STATUS[$l['new_status']]??'') ?></span></td><td><?= e($l['who']?:'—') ?></td><td><?= e($l['created_at']) ?></td></tr><?php endforeach; ?>
<?php if(!$log) echo '<tr><td colspan="5" class="empty">لا توجد تغييرات بعد</td></tr>'; ?></table></div></div>
