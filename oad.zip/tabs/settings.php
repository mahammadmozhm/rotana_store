<?php
if($_SERVER['REQUEST_METHOD']==='POST'){ check_csrf();
  set_setting('site_name',trim($_POST['site_name'])?:'نظام الطلبات'); set_setting('footer_text',trim($_POST['footer_text']));
  foreach(['color_primary','color_secondary'] as $k) if(preg_match('/^#[0-9a-f]{6}$/i',$_POST[$k]??'')) set_setting($k,$_POST[$k]);
  if(!empty($_POST['rm_logo'])) set_setting('logo','');
  $f=$_FILES['logo']??null;
  if($f&&$f['error']===0){ $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
    if(in_array($ext,['png','jpg','jpeg','webp','gif'])&&@getimagesize($f['tmp_name'])&&$f['size']<2000000){
      $n='logo_'.bin2hex(random_bytes(4)).'.'.$ext; move_uploaded_file($f['tmp_name'],__DIR__.'/../uploads/'.$n); set_setting('logo',$n); }
    else flash('صورة الشعار غير صالحة (png/jpg/webp حتى 2MB)','err'); }
  if(empty($_SESSION['flash'])) flash('تم حفظ الإعدادات'); redir('?tab=settings'); }
?>
<div class="card" style="max-width:560px"><h3>إعدادات الموقع</h3>
<form method="post" enctype="multipart/form-data"><?= csrf_field() ?>
<label>اسم الموقع<input name="site_name" value="<?= e(setting('site_name','نظام الطلبات')) ?>"></label>
<div class="row2"><label>اللون الأساسي<input type="color" name="color_primary" value="<?= e(setting('color_primary','#2563eb')) ?>"></label>
<label>لون الشريط العلوي<input type="color" name="color_secondary" value="<?= e(setting('color_secondary','#0f172a')) ?>"></label></div>
<label>الشعار (لوكو)<input type="file" name="logo" accept="image/*"></label>
<?php if(setting('logo')): ?><img src="uploads/<?= e(setting('logo')) ?>" height="48" alt=""><label><input type="checkbox" name="rm_logo"> حذف الشعار</label><?php endif; ?>
<label>نص الفوتر<input name="footer_text" value="<?= e(setting('footer_text')) ?>"></label>
<button class="btn">حفظ</button></form></div>
