<?php
$base=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['SCRIPT_NAME']),'/\\').'/telegram.php';
if($_SERVER['REQUEST_METHOD']==='POST'){ check_csrf();
  set_setting('tg_token',trim($_POST['token'])); set_setting('tg_chat_ids',preg_replace('/\s+/','',$_POST['chats']));
  if(!setting('tg_secret')) set_setting('tg_secret',bin2hex(random_bytes(16)));
  if(isset($_POST['hook'])){ $r=tg('setWebhook',['url'=>$base,'secret_token'=>setting('tg_secret')]);
    flash(!empty($r['ok'])?'تم ربط البوت بنجاح':'فشل الربط: '.($r['description']??'تأكد من التوكن ومن أن الرابط HTTPS عام'),!empty($r['ok'])?'ok':'err'); }
  else flash('تم الحفظ');
  redir('?tab=telegram'); }
?>
<div class="card" style="max-width:640px"><h3>ربط بوت تلكرام لاستيراد الطلبات</h3>
<ol><li>أنشئ بوت من <b>@BotFather</b> وانسخ التوكن.</li>
<li>الصق التوكن هنا، واضغط «حفظ وربط».</li>
<li>أرسل أي رسالة للبوت؛ سيرد عليك بـ <b>معرّف المحادثة</b>، ضعه في خانة المعرّفات المسموحة واحفظ.</li>
<li>بعدها أرسل للبوت ملف Excel (xlsx) أو CSV بنفس أعمدة الملف التجريبي وسيُنشئ الطلبات تلقائياً.</li></ol>
<p>⚠ تلكرام يتطلب رابط <b>HTTPS عام</b>. محلياً استخدم ngrok أو cloudflared.</p>
<form method="post"><?= csrf_field() ?>
<label>توكن البوت<input name="token" value="<?= e(setting('tg_token')) ?>" placeholder="123456:ABC..."></label>
<label>معرّفات المحادثات المسموحة (مفصولة بفاصلة)<input name="chats" value="<?= e(setting('tg_chat_ids')) ?>"></label>
<p>رابط الويب هوك: <code><?= e($base) ?></code></p>
<button class="btn" name="hook" value="1">حفظ وربط</button> <button class="btn sec">حفظ فقط</button></form></div>
