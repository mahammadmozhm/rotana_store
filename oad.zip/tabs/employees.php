<?php
if($_SERVER['REQUEST_METHOD']==='POST'){ check_csrf(); $act=$_POST['act']??'';
  if($act==='delete'){ $pdo->prepare("DELETE FROM users WHERE id=? AND role='staff'")->execute([(int)$_POST['id']]); flash('تم حذف الموظف'); redir('?tab=employees'); }
  if($act==='save'){ $id=(int)($_POST['id']??0); $pw=$_POST['password']??'';
    $d=[trim($_POST['full_name']),trim($_POST['username']),trim($_POST['phone']),isset($_POST['perm_status'])?1:0,isset($_POST['perm_orders'])?1:0,isset($_POST['perm_reports'])?1:0,isset($_POST['active'])?1:0];
    try{
      if($id){ $sql="UPDATE users SET full_name=?,username=?,phone=?,perm_status=?,perm_orders=?,perm_reports=?,active=?"; $p=$d;
        if($pw!==''){ $sql.=",password=?"; $p[]=password_hash($pw,PASSWORD_DEFAULT); }
        $p[]=$id; $pdo->prepare($sql." WHERE id=? AND role='staff'")->execute($p); flash('تم تعديل الموظف'); }
      else { if($pw===''){ flash('كلمة المرور مطلوبة','err'); redir('?tab=employees'); }
        $pdo->prepare("INSERT INTO users(full_name,username,phone,perm_status,perm_orders,perm_reports,active,password,role) VALUES(?,?,?,?,?,?,?,?,'staff')")->execute(array_merge($d,[password_hash($pw,PASSWORD_DEFAULT)])); flash('تم إنشاء الحساب'); }
    }catch(PDOException $x){ flash('اسم المستخدم مستخدم مسبقاً','err'); }
    redir('?tab=employees'); } }
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM users WHERE id=? AND role='staff'"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null; }
$list=$pdo->query("SELECT * FROM users WHERE role='staff' ORDER BY id DESC")->fetchAll();
?>
<div class="card"><h3><?= $edit?'تعديل موظف':'إضافة موظف' ?></h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
<div class="row2">
<label>الاسم الثلاثي<input name="full_name" required value="<?= e($edit['full_name']??'') ?>"></label>
<label>اسم المستخدم<input name="username" required value="<?= e($edit['username']??'') ?>"></label>
<label>كلمة المرور <?= $edit?'(اتركها فارغة لعدم التغيير)':'' ?><input type="password" name="password" autocomplete="new-password" <?= $edit?'':'required' ?>></label>
<label>رقم الهاتف<input name="phone" value="<?= e($edit['phone']??'') ?>"></label></div>
<b>الصلاحيات:</b><br>
<label><input type="checkbox" name="perm_status" <?= ($edit['perm_status']??1)?'checked':'' ?>> تعديل حالة الطلبات</label>
<label><input type="checkbox" name="perm_orders" <?= ($edit['perm_orders']??0)?'checked':'' ?>> إضافة/استيراد وإدارة الطلبات</label>
<label><input type="checkbox" name="perm_reports" <?= ($edit['perm_reports']??0)?'checked':'' ?>> عرض التقارير</label>
<label><input type="checkbox" name="active" <?= ($edit['active']??1)?'checked':'' ?>> الحساب فعّال</label>
<button class="btn"><?= $edit?'حفظ':'إضافة' ?></button> <?php if($edit) echo '<a class="btn sec" href="?tab=employees">إلغاء</a>'; ?>
</form></div>
<div class="card tw"><table><tr><th>الاسم</th><th>المستخدم</th><th>الهاتف</th><th>الصلاحيات</th><th>الحالة</th><th></th></tr>
<?php foreach($list as $u): ?><tr><td><?= e($u['full_name']) ?></td><td><?= e($u['username']) ?></td><td><?= e($u['phone']) ?></td>
<td><?= $u['perm_status']?'حالة ':'' ?><?= $u['perm_orders']?'• طلبات ':'' ?><?= $u['perm_reports']?'• تقارير':'' ?></td><td><?= $u['active']?'فعّال':'معطّل' ?></td>
<td><a class="btn sm" href="?tab=employees&edit=<?= $u['id'] ?>">تعديل</a>
<form class="inline" method="post" data-confirm="حذف هذا الموظف؟"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $u['id'] ?>"><button class="btn sm red">حذف</button></form></td></tr><?php endforeach; ?>
<?php if(!$list) echo '<tr><td colspan="6" class="empty">لا يوجد موظفون</td></tr>'; ?></table></div>
