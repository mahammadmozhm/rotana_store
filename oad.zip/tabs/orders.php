<?php
if($_SERVER['REQUEST_METHOD']==='POST'){ check_csrf(); $act=$_POST['act']??'';
  if($act==='delete'){ $pdo->prepare("DELETE FROM orders WHERE id=?")->execute([(int)$_POST['id']]); flash('تم حذف الطلب'); redir('?tab=orders'); }
  if($act==='save'){ $id=(int)($_POST['id']??0); $d=[trim($_POST['order_no']),trim($_POST['full_name']),trim($_POST['phone']),trim($_POST['region'])];
    if($d[0]===''){ flash('رقم الطلب مطلوب','err'); redir('?tab=orders'); }
    try{ if($id){ $pdo->prepare("UPDATE orders SET order_no=?,full_name=?,phone=?,region=? WHERE id=?")->execute(array_merge($d,[$id])); }
      else { $pdo->prepare("INSERT INTO orders(order_no,full_name,phone,region) VALUES(?,?,?,?)")->execute($d); $id=$pdo->lastInsertId(); }
      save_assign($id,posted_assign()); flash('تم حفظ الطلب'); }
    catch(PDOException $x){ flash('رقم الطلب موجود مسبقاً','err'); }
    redir('?tab=orders'); }
  if($act==='import'){ $f=$_FILES['file']??null; $ext=strtolower(pathinfo($f['name']??'',PATHINFO_EXTENSION));
    if(!$f||$f['error']||!in_array($ext,['xlsx','csv'])){ flash('ارفع ملف xlsx أو csv','err'); redir('?tab=orders'); }
    [$a,$s]=import_rows(read_sheet($f['tmp_name'],$ext),posted_assign());
    flash("تم استيراد $a طلب، وتخطي $s (مكرر/خطأ)"); redir('?tab=orders'); } }
$edit=null;$sel=[];
if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM orders WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null;
  if($edit){ $s=$pdo->prepare("SELECT user_id FROM order_users WHERE order_id=?"); $s->execute([$edit['id']]); $sel=array_map('intval',$s->fetchAll(PDO::FETCH_COLUMN)); } }
$q=trim($_GET['s']??''); $pg=max(1,(int)($_GET['p']??1)); $per=50;
$s=$pdo->prepare("SELECT o.*,(SELECT GROUP_CONCAT(u.full_name SEPARATOR '، ') FROM order_users ou JOIN users u ON u.id=ou.user_id WHERE ou.order_id=o.id) AS vis FROM orders o WHERE o.order_no LIKE ? OR o.full_name LIKE ? OR o.phone LIKE ? ORDER BY o.id DESC LIMIT $per OFFSET ".(($pg-1)*$per));
$like='%'.$q.'%'; $s->execute([$like,$like,$like]); $list=$s->fetchAll();
?>
<div class="card"><h3><?= $edit?'تعديل طلب':'إضافة طلب يدوياً' ?></h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
<div class="row2">
<label>رقم الطلب<input name="order_no" required value="<?= e($edit['order_no']??'') ?>"></label>
<label>الاسم الثلاثي<input name="full_name" value="<?= e($edit['full_name']??'') ?>"></label>
<label>رقم الهاتف<input name="phone" inputmode="tel" value="<?= e($edit['phone']??'') ?>"></label>
<label>المنطقة<input name="region" value="<?= e($edit['region']??'') ?>"></label></div>
<b>من يرى الطلب؟</b><?= assign_box($staff,$sel) ?><br>
<button class="btn"><?= $edit?'حفظ':'إضافة' ?></button> <?php if($edit) echo '<a class="btn sec" href="?tab=orders">إلغاء</a>'; ?>
</form></div>

<div class="card"><h3>استيراد طلبات من Excel</h3>
<p>الأعمدة بالترتيب: رقم الطلب | الاسم الثلاثي | رقم الهاتف | المنطقة (xlsx أو csv). <a href="export_template.php">⬇ تنزيل ملف تجريبي</a></p>
<form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="act" value="import">
<input type="file" name="file" accept=".xlsx,.csv" required>
<b>من يرى الطلبات المستوردة؟</b><?= assign_box($staff) ?><br><button class="btn">استيراد</button></form></div>

<div class="card"><form method="get"><input type="hidden" name="tab" value="orders"><input name="s" placeholder="بحث في الطلبات..." value="<?= e($q) ?>"></form></div>
<div class="card tw"><table><tr><th>الطلب</th><th>الاسم</th><th>الهاتف</th><th>المنطقة</th><th>الحالة</th><th>يراها</th><th></th></tr>
<?php foreach($list as $o): ?><tr><td>#<?= e($o['order_no']) ?></td><td><?= e($o['full_name']) ?></td><td><?= e($o['phone']) ?></td><td><?= e($o['region']) ?></td>
<td><span class="st st-<?= $o['status'] ?>"><?= STATUS[$o['status']] ?></span></td><td><?= e($o['vis']?:'الجميع') ?></td>
<td><a class="btn sm" href="?tab=orders&edit=<?= $o['id'] ?>">تعديل</a>
<form class="inline" method="post" data-confirm="حذف الطلب؟"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $o['id'] ?>"><button class="btn sm red">حذف</button></form></td></tr><?php endforeach; ?>
<?php if(!$list) echo '<tr><td colspan="7" class="empty">لا توجد طلبات</td></tr>'; ?></table>
<p><?php if($pg>1) echo '<a href="?tab=orders&s='.urlencode($q).'&p='.($pg-1).'">« السابق</a> '; if(count($list)===$per) echo '<a href="?tab=orders&s='.urlencode($q).'&p='.($pg+1).'">التالي »</a>'; ?></p></div>
