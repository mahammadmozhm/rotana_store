<?php
if($_SERVER['REQUEST_METHOD']==='POST'){ check_csrf();
  if(!password_verify($_POST['cur']??'',$me['password'])) flash('كلمة المرور الحالية غير صحيحة','err');
  elseif(trim($_POST['username'])==='') flash('اسم المستخدم مطلوب','err');
  else { try{ $sql="UPDATE users SET username=?"; $p=[trim($_POST['username'])];
      if(($_POST['new']??'')!==''){ $sql.=",password=?"; $p[]=password_hash($_POST['new'],PASSWORD_DEFAULT); }
      $p[]=$me['id']; $pdo->prepare($sql." WHERE id=?")->execute($p); flash('تم تحديث حساب الأدمن'); }
    catch(PDOException $x){ flash('اسم المستخدم مستخدم','err'); } }
  redir('?tab=account'); }
?>
<div class="card" style="max-width:460px"><h3>تعديل اسم المستخدم وكلمة مرور الأدمن</h3>
<form method="post"><?= csrf_field() ?>
<label>اسم المستخدم<input name="username" required value="<?= e($me['username']) ?>"></label>
<label>كلمة المرور الجديدة (اختياري)<input type="password" name="new" autocomplete="new-password"></label>
<label>كلمة المرور الحالية (للتأكيد)<input type="password" name="cur" required></label>
<button class="btn">حفظ</button></form></div>
