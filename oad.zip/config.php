<?php
// إعدادات قاعدة البيانات (XAMPP الافتراضي)
define('DB_HOST','sql303.infinityfree.com');
define('DB_NAME','if0_39046264_seedf');
define('DB_USER','if0_39046264');
define('DB_PASS','B5jcwKtShxTY9o');
