-- Database schema for orders-system
-- Import this file using phpMyAdmin or MySQL.
-- Default login: admin / admin123 (change immediately after login).

CREATE DATABASE IF NOT EXISTS `orders_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `orders_db`;

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(150) NOT NULL,
  `username` VARCHAR(60) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(30) DEFAULT '',
  `role` ENUM('admin','staff') DEFAULT 'staff',
  `perm_status` TINYINT DEFAULT 1,
  `perm_orders` TINYINT DEFAULT 0,
  `perm_reports` TINYINT DEFAULT 0,
  `active` TINYINT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `order_no` VARCHAR(50) NOT NULL,
  `full_name` VARCHAR(150) DEFAULT '',
  `phone` VARCHAR(30) DEFAULT '',
  `region` VARCHAR(100) DEFAULT '',
  `status` ENUM('pending','delivered','rejected') DEFAULT 'pending',
  `updated_by` INT DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_orders_order_no` (`order_no`),
  KEY `idx_orders_updated_by` (`updated_by`),
  CONSTRAINT `fk_orders_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `order_users` (
  `order_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  PRIMARY KEY (`order_id`,`user_id`),
  KEY `idx_order_users_user_id` (`user_id`),
  CONSTRAINT `fk_order_users_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order_users_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `status_log` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `order_id` INT NOT NULL,
  `user_id` INT DEFAULT NULL,
  `old_status` VARCHAR(20) DEFAULT NULL,
  `new_status` VARCHAR(20) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status_log_order_id` (`order_id`),
  KEY `idx_status_log_user_id` (`user_id`),
  CONSTRAINT `fk_status_log_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_status_log_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `settings` (
  `k` VARCHAR(50) NOT NULL,
  `v` TEXT DEFAULT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `users`
  (`full_name`,`username`,`password`,`role`,`perm_status`,`perm_orders`,`perm_reports`,`active`)
VALUES
  ('المدير','admin','$2y$12$H80UCWARhPfgVOTPWYeumOSRIjftaDGA5kMiO8fsmNmFu5VreRUta','admin',1,1,1,1);

INSERT IGNORE INTO `settings` (`k`,`v`) VALUES
  ('site_name','نظام الطلبات'),
  ('color_primary','#2563eb'),
  ('color_secondary','#0f172a'),
  ('footer_text','جميع الحقوق محفوظة');
