<?php
ob_start();
require __DIR__.'/config.php';
session_start();
date_default_timezone_set('Asia/Baghdad');
try{
  $pdo=new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",DB_USER,DB_PASS,[
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
  ]);
  // تعيين المنطقة الزمنية للعراق دون استخدام الثابت القديم المحذوف في PHP 8.5
  $pdo->exec("SET time_zone = '+03:00'");
}catch(Exception $e){ die('تعذر الاتصال بقاعدة البيانات. تأكد من config.php ثم شغّل install.php'); }

const STATUS=['pending'=>'غير مصنف','delivered'=>'تم التوصيل','rejected'=>'تم رفض التوصيل'];

function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function setting($k,$d=''){ global $pdo; $s=$pdo->prepare("SELECT v FROM settings WHERE k=?"); $s->execute([$k]); $v=$s->fetchColumn(); return ($v===false||$v==='')?$d:$v; }
function set_setting($k,$v){ global $pdo; $pdo->prepare("REPLACE INTO settings(k,v) VALUES(?,?)")->execute([$k,$v]); }
function redir($u){ header('Location: '.$u); exit; }
function flash($m,$t='ok'){ $_SESSION['flash']=[$m,$t]; }
function show_flash(){ if(!empty($_SESSION['flash'])){ [$m,$t]=$_SESSION['flash']; unset($_SESSION['flash']); echo '<div class="alert '.$t.'">'.e($m).'</div>'; } }

function user(){ static $u=false; global $pdo;
  if($u===false){ $u=null; if(!empty($_SESSION['uid'])){ $s=$pdo->prepare("SELECT * FROM users WHERE id=? AND active=1"); $s->execute([$_SESSION['uid']]); $u=$s->fetch()?:null; } }
  return $u; }
function require_login(){ $u=user(); if(!$u) redir('login.php'); return $u; }
function is_admin(){ $u=user(); return $u && $u['role']==='admin'; }
function can($p){ $u=user(); return $u && ($u['role']==='admin' || !empty($u['perm_'.$p])); }
function csrf(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function csrf_field(){ return '<input type="hidden" name="csrf" value="'.csrf().'">'; }
function check_csrf(){ if(!hash_equals($_SESSION['csrf']??'x',$_POST['csrf']??'')){ http_response_code(400); die('طلب غير صالح (CSRF)'); } }

// شرط ظهور الطلبات: الأدمن يرى الكل، الموظف يرى الطلبات العامة + المخصصة له
function visible_sql($a='o'){ $u=user(); if($u['role']==='admin') return ['1=1',[]];
  return ["(NOT EXISTS(SELECT 1 FROM order_users x WHERE x.order_id=$a.id) OR EXISTS(SELECT 1 FROM order_users y WHERE y.order_id=$a.id AND y.user_id=?))",[$u['id']]]; }

function change_status($id,$new,$uid){ global $pdo;
  if(!isset(STATUS[$new])) return false;
  $s=$pdo->prepare("SELECT status FROM orders WHERE id=?"); $s->execute([$id]); $old=$s->fetchColumn();
  if($old===false||$old===$new) return false;
  $pdo->prepare("UPDATE orders SET status=?,updated_by=?,updated_at=NOW() WHERE id=?")->execute([$new,$uid,$id]);
  $pdo->prepare("INSERT INTO status_log(order_id,user_id,old_status,new_status) VALUES(?,?,?,?)")->execute([$id,$uid,$old,$new]);
  return true; }

function head($title){ $u=user(); $logo=setting('logo');
  $c1=preg_match('/^#[0-9a-f]{6}$/i',setting('color_primary'))?setting('color_primary'):'#2563eb';
  $c2=preg_match('/^#[0-9a-f]{6}$/i',setting('color_secondary'))?setting('color_secondary'):'#0f172a';
  echo '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
  echo '<meta name="csrf" content="'.csrf().'"><title>'.e($title).' - '.e(setting('site_name','نظام الطلبات')).'</title>';
  echo '<link rel="stylesheet" href="assets/style.css"><style>:root{--p:'.$c1.';--s:'.$c2.'}</style></head><body>';
  echo '<header class="top"><a class="brand" href="index.php">'.($logo?'<img src="uploads/'.e($logo).'" alt="">':'').'<span>'.e(setting('site_name','نظام الطلبات')).'</span></a>';
  if($u){ echo '<nav><a href="index.php">الرئيسية</a>';
    if(can('reports')) echo '<a href="reports.php">التقارير</a>';
    if(can('orders')) echo '<a href="dashboard.php">لوحة التحكم</a>';
    echo '<a href="logout.php">خروج ('.e($u['username']).')</a></nav>'; }
  echo '</header><main class="wrap">'; }
function foot(){ echo '</main><footer>'.e(setting('footer_text','')).'</footer><script src="assets/app.js"></script></body></html>'; }
