<?php require 'inc.php';
if(user()) redir('index.php');
$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ check_csrf();
  $s=$pdo->prepare("SELECT * FROM users WHERE username=? AND active=1"); $s->execute([trim($_POST['username']??'')]); $u=$s->fetch();
  if($u && password_verify($_POST['password']??'',$u['password'])){ session_regenerate_id(true); $_SESSION['uid']=$u['id']; redir('index.php'); }
  $err='اسم المستخدم أو كلمة المرور غير صحيحة'; }
head('تسجيل الدخول'); ?>
<form class="card login" method="post">
  <h2>تسجيل الدخول</h2>
  <?php if($err) echo '<div class="alert err">'.e($err).'</div>'; ?>
  <?= csrf_field() ?>
  <label>اسم المستخدم<input name="username" required autofocus autocomplete="username"></label>
  <label>كلمة المرور<input type="password" name="password" required autocomplete="current-password"></label>
  <button class="btn">دخول</button>
</form>
<?php foot();
