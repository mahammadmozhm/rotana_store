<?php require 'inc.php'; require 'lib.php'; $me=require_login(); if(!can('reports')) redir('index.php');
$df=(($_GET['df']??'')==='updated_at')?'o.updated_at':'o.created_at';
$from=$_GET['from']??''; $to=$_GET['to']??''; $st=$_GET['status']??''; $emp=(int)($_GET['emp']??0); $reg=trim($_GET['region']??'');
[$w,$p]=visible_sql('o'); $w=[$w];
if($from){ $w[]="$df>=?"; $p[]=$from.' 00:00:00'; } if($to){ $w[]="$df<=?"; $p[]=$to.' 23:59:59'; }
if(isset(STATUS[$st])){ $w[]='o.status=?'; $p[]=$st; } if($emp){ $w[]='o.updated_by=?'; $p[]=$emp; }
if($reg!==''){ $w[]='o.region LIKE ?'; $p[]='%'.$reg.'%'; }
$W=implode(' AND ',$w);
$base="FROM orders o LEFT JOIN users u ON u.id=o.updated_by WHERE $W";
if(isset($_GET['export'])){
  $s=$pdo->prepare("SELECT o.order_no,o.full_name,o.phone,o.region,o.status,u.full_name AS by_name,o.updated_at,o.created_at $base ORDER BY o.id DESC"); $s->execute($p);
  $rows=[['رقم الطلب','الاسم','الهاتف','المنطقة','الحالة','آخر تعديل بواسطة','تاريخ التعديل','تاريخ الإنشاء']];
  foreach($s->fetchAll() as $r){ $r['status']=STATUS[$r['status']]; $rows[]=array_values($r); }
  if($_GET['export']==='csv'){ header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="report.csv"'); echo "\xEF\xBB\xBF"; $o=fopen('php://output','w'); foreach($rows as $r) fputcsv($o,$r); exit; }
  $tmp=tempnam(sys_get_temp_dir(),'rp'); xlsx_write($rows,$tmp);
  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); header('Content-Disposition: attachment; filename="report.xlsx"'); readfile($tmp); unlink($tmp); exit; }
$s=$pdo->prepare("SELECT o.status,COUNT(*) $base GROUP BY o.status"); $s->execute($p); $cnt=$s->fetchAll(PDO::FETCH_KEY_PAIR);
$s=$pdo->prepare("SELECT COALESCE(u.full_name,'—') n,o.status,COUNT(*) c $base GROUP BY u.id,o.status ORDER BY n"); $s->execute($p);
$byEmp=[]; foreach($s->fetchAll() as $r) $byEmp[$r['n']][$r['status']]=$r['c'];
$s=$pdo->prepare("SELECT o.*,u.full_name AS by_name $base ORDER BY o.id DESC LIMIT 200"); $s->execute($p); $list=$s->fetchAll();
$emps=$pdo->query("SELECT id,full_name FROM users ORDER BY full_name")->fetchAll();
$qs=http_build_query(array_filter(['df'=>$_GET['df']??'','from'=>$from,'to'=>$to,'status'=>$st,'emp'=>$emp?:'','region'=>$reg]));
head('التقارير'); ?>
<div class="card"><form method="get"><div class="row2">
<label>حسب تاريخ<select name="df"><option value="created_at">الإنشاء</option><option value="updated_at" <?= $df==='o.updated_at'?'selected':'' ?>>آخر تعديل</option></select></label>
<label>من<input type="date" name="from" value="<?= e($from) ?>"></label><label>إلى<input type="date" name="to" value="<?= e($to) ?>"></label>
<label>الحالة<select name="status"><option value="">الكل</option><?php foreach(STATUS as $k=>$n) echo '<option value="'.$k.'"'.($st===$k?' selected':'').'>'.$n.'</option>'; ?></select></label>
<label>الموظف<select name="emp"><option value="0">الكل</option><?php foreach($emps as $x) echo '<option value="'.$x['id'].'"'.($emp==$x['id']?' selected':'').'>'.e($x['full_name']).'</option>'; ?></select></label>
<label>المنطقة<input name="region" value="<?= e($reg) ?>"></label></div>
<button class="btn">عرض</button> <a class="btn sec" href="?<?= e($qs) ?>&export=xlsx">تصدير Excel</a> <a class="btn sec" href="?<?= e($qs) ?>&export=csv">تصدير CSV</a></form></div>
<div class="grid"><div class="card stat"><b><?= array_sum($cnt) ?></b>الإجمالي</div>
<?php foreach(STATUS as $k=>$n) echo '<div class="card stat"><b>'.(int)($cnt[$k]??0).'</b>'.$n.'</div>'; ?></div>
<div class="card tw"><h3>حسب الموظف (آخر من عدّل الحالة)</h3><table><tr><th>الموظف</th><?php foreach(STATUS as $n) echo "<th>$n</th>"; ?></tr>
<?php foreach($byEmp as $n=>$r){ echo '<tr><td>'.e($n).'</td>'; foreach(STATUS as $k=>$_) echo '<td>'.(int)($r[$k]??0).'</td>'; echo '</tr>'; } ?></table></div>
<div class="card tw"><h3>تفاصيل الطلبات (أول 200 — التصدير يشمل الكل)</h3><table><tr><th>الطلب</th><th>الاسم</th><th>الهاتف</th><th>المنطقة</th><th>الحالة</th><th>بواسطة</th><th>التعديل</th></tr>
<?php foreach($list as $o): ?><tr><td>#<?= e($o['order_no']) ?></td><td><?= e($o['full_name']) ?></td><td><?= e($o['phone']) ?></td><td><?= e($o['region']) ?></td><td><span class="st st-<?= $o['status'] ?>"><?= STATUS[$o['status']] ?></span></td><td><?= e($o['by_name']?:'—') ?></td><td><?= e($o['updated_at']) ?></td></tr><?php endforeach; ?></table></div>
<?php foot();
