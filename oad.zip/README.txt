خطوات التشغيل (XAMPP):
1) انسخ المجلد إلى C:\xampp\htdocs\orders-system وشغّل Apache و MySQL.
2) عدّل config.php إن لزم (المستخدم root وبدون كلمة مرور افتراضياً).
3) افتح http://localhost/orders-system/install.php لإنشاء قاعدة البيانات.
4) سجّل الدخول: admin / admin123 ثم غيّرهما من لوحة التحكم > حساب الأدمن. واحذف install.php.
متطلبات PHP: 7.4+ مع إضافات pdo_mysql, zip, curl, simplexml.
