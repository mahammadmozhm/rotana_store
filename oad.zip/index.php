<?php require 'inc.php'; require_login();
head('الرئيسية'); ?>
<div class="searchbox">
  <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
  <input id="q" type="search" inputmode="numeric" placeholder="ابحث برقم الطلب..." autofocus autocomplete="off">
</div>
<div id="results"></div>
<?php foot();
